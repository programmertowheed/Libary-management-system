<!DOCTYPE html>
<html>
<head>
	<title>404</title>
	<style type="text/css">
		.wraper {
		    margin: 0 auto;
		    text-align: center;
		    margin-top: 150px;
		}

		body {
		    height: 100%;
		    background: red;
		}

		h1.h1 {
		    font-size: 200px;
		    padding: 0;
		    margin: 0;
		}

		h6.h6 {
		    font-size: 100px;
		    padding: 0;
		    margin: 0;
		}
		.rote4{
			display: inline-block;
    		transform: rotateY(180deg);
		}

		.be40{
			display: inline-block;
		}


	</style>
</head>
<body>
	<div class="wraper">
		<h1 class="h1"><div class="be40">40</div><div class="rote4">4</div></h1>
		<h6 class="h6">Not Found</h6>
	</div>
</body>
</html>